// Devuelve la fecha con el formato dd/mm/aaaa hh:mm:ss
function formatearFecha(fecha) {
  const dos = (n) => String(n).padStart(2, "0");

  return (
    dos(fecha.getDate()) + "/" +
    dos(fecha.getMonth() + 1) + "/" +
    fecha.getFullYear() + " " +
    dos(fecha.getHours()) + ":" +
    dos(fecha.getMinutes()) + ":" +
    dos(fecha.getSeconds())
  );
}

// Middleware de registro: se ejecuta en todas las peticiones y cede el
// control con next(); si no, la petición se quedaría esperando.
export function registrarPeticion(req, res, next) {
  console.log("[" + formatearFecha(new Date()) + "] " + req.method + " " + req.originalUrl);
  next();
}
