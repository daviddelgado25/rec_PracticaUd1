// Importo los módulos nativos de Node para manejar rutas y los paquetes/módulos propios del proyecto
import path from "node:path";
import { fileURLToPath } from "node:url";
import express from "express";
import { talleres, inscripciones } from "./datos.js";
import {
  parsearId,
  obtenerPlazasRestantes,
  estaInscrito,
  normalizarInscripcion,
  validarInscripcion,
  siguienteId
} from "./utils.js";
import { registrarPeticion } from "./middleware.js";

// Inicializo la aplicación Express y defino el puerto de escucha
const app = express();
const PORT = 3000;

// Calculo las rutas absolutas del proyecto para evitar fallos si arranco el servidor desde otro directorio
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const raiz = path.join(__dirname, "..");

// Configuro EJS como motor de plantillas e indico la carpeta donde están las vistas
app.set("view engine", "ejs");
app.set("views", path.join(raiz, "views"));

// Registro mi middleware propio el primero para que quede constancia de todas las peticiones (existan o no)
app.use(registrarPeticion);

// Configuro el middleware para leer datos de formularios POST y servir los archivos estáticos de la carpeta public
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(raiz, "public")));

// Redirijo la ruta raíz directamente al listado principal de talleres
app.get("/", (req, res) => {
  res.redirect("/talleres");
});

// Gestiono el listado de talleres aplicando de forma acumulativa los filtros opcionales por query string
app.get("/talleres", (req, res) => {
  // Normalizo los parámetros recibidos en la URL para evitar problemas con espacios o mayúsculas
  const categoria = String(req.query.categoria ?? "")
    .trim()
    .toLowerCase();

  const nivel = String(req.query.nivel ?? "")
    .trim()
    .toLowerCase();

  const disponibles = req.query.disponibles === "true";

  // Parto de la colección original sin mutarla y voy filtrando según los criterios activos
  let resultado = talleres;

  if (categoria) {
    resultado = resultado.filter((taller) => {
      return taller.categoria.toLowerCase() === categoria;
    });
  }

  if (nivel) {
    resultado = resultado.filter((taller) => {
      return taller.nivel.toLowerCase() === nivel;
    });
  }

  if (disponibles) {
    resultado = resultado.filter((taller) => {
      return obtenerPlazasRestantes(taller, inscripciones) > 0;
    });
  }

  // Transformo cada taller con map() añadiendo las plazas restantes calculadas para que la vista solo tenga que pintarlas
  const datos = resultado.map((taller) => {
    return {
      ...taller,
      plazasRestantes: obtenerPlazasRestantes(taller, inscripciones)
    };
  });

  // Renderizo la vista del catálogo pasando los talleres filtrados y el estado actual de los filtros
  res.render("talleres", {
    talleres: datos,
    filtros: {
      categoria,
      nivel,
      disponibles
    }
  });
});

// Muestro la ficha individual de un taller validando primero que el id sea numérico y exista
app.get("/talleres/:id", (req, res) => {
  const id = parsearId(req.params.id);

  // Si el identificador está manipulado o no es un entero positivo, devuelvo error 400
  if (id === null) {
    return res.status(400).render("error", {
      mensaje: "Identificador no válido"
    });
  }

  // Busco el taller con find(); si no existe en memoria, devuelvo error 404
  const taller = talleres.find((taller) => taller.id === id);

  if (!taller) {
    return res.status(404).render("error", {
      mensaje: "Taller no encontrado"
    });
  }

  // Calculo las plazas disponibles y renderizo la ficha del taller
  const plazasRestantes = obtenerPlazasRestantes(taller, inscripciones);

  res.render("taller", {
    taller,
    plazasRestantes
  });
});

// Muestro el formulario de inscripción comprobando antes que el taller existe y aún tiene plazas libres
app.get("/talleres/:id/inscripcion", (req, res) => {
  const id = parsearId(req.params.id);

  if (id === null) {
    return res.status(400).render("error", {
      mensaje: "Identificador no válido"
    });
  }

  const taller = talleres.find((taller) => taller.id === id);

  if (!taller) {
    return res.status(404).render("error", {
      mensaje: "Taller no encontrado"
    });
  }

  // Impido el acceso directo por URL al formulario si el taller ya está completo
  if (obtenerPlazasRestantes(taller, inscripciones) <= 0) {
    return res.status(400).render("error", {
      mensaje: "El taller está completo y no admite más inscripciones"
    });
  }

  // Renderizo el formulario vacío la primera vez que entra el usuario
  res.render("inscripcion", {
    taller,
    valores: {
      nombre: "",
      email: ""
    },
    errores: {}
  });
});

// Proceso el envío del formulario de inscripción validando todas las reglas de negocio en servidor
app.post("/talleres/:id/inscripcion", (req, res) => {
  const id = parsearId(req.params.id);

  if (id === null) {
    return res.status(400).render("error", {
      mensaje: "Identificador no válido"
    });
  }

  const taller = talleres.find((taller) => taller.id === id);

  if (!taller) {
    return res.status(404).render("error", {
      mensaje: "Taller no encontrado"
    });
  }

  // Normalizo los datos recibidos en req.body y ejecuto las validaciones de formato
  const datos = normalizarInscripcion(req.body);
  const errores = validarInscripcion(datos);

  // Compruebo que queden plazas disponibles en el momento de procesar la petición
  if (obtenerPlazasRestantes(taller, inscripciones) <= 0) {
    errores.general = "El taller está completo";
  }

  // Si el formato del email es válido, verifico que no esté ya apuntado a este mismo taller
  if (!errores.email && estaInscrito(id, datos.email, inscripciones)) {
    errores.email = "Ya hay una inscripción con ese email";
  }

  // Si hay algún fallo, vuelvo a pintar el formulario con código 400 conservando los datos correctos y mostrando errores
  if (Object.keys(errores).length > 0) {
    return res.status(400).render("inscripcion", {
      taller,
      valores: datos,
      errores
    });
  }

  // Guardo la nueva inscripción en memoria generando un identificador único
  inscripciones.push({
    id: siguienteId(inscripciones),
    tallerId: id,
    nombre: datos.nombre,
    email: datos.email
  });

  // Aplico el patrón PRG (Post-Redirect-Get) con código 303 para evitar duplicar el alta si el usuario recarga la página
  res.redirect(303, "/talleres/" + id);
});

// Capturo cualquier ruta no definida anteriormente y renderizo la vista personalizada de error 404
app.use((req, res) => {
  res.status(404).render("404", {
    ruta: req.originalUrl
  });
});

// Middleware global de errores (4 parámetros) para capturar fallos inesperados sin exponer detalles técnicos al cliente
app.use((error, req, res, next) => {
  console.error(error);
  res.status(500).render("error", {
    mensaje: "Error interno del servidor"
  });
});

// Arranco el servidor HTTP en el puerto configurado
app.listen(PORT, () => {
  console.log("Servidor funcionando en http://localhost:" + PORT);
});