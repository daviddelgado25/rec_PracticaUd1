// Valido y convierto el parámetro de ruta id a entero positivo, devolviendo null si contiene caracteres no numéricos
export function parsearId(texto) {
  const limpio = String(texto ?? "").trim();

  // Uso una expresión regular para aceptar únicamente dígitos y bloquear formatos como "0x1" o "1e0"
  if (!/^\d+$/.test(limpio)) {
    return null;
  }

  const id = Number(limpio);

  if (!Number.isSafeInteger(id) || id <= 0) {
    return null;
  }

  return id;
}

// Calculo las plazas libres de un taller filtrando sus inscripciones actuales y restándolas del aforo total
export function obtenerPlazasRestantes(taller, inscripciones) {
  if (!taller) {
    return 0;
  }

  const apuntados = inscripciones.filter(
    (inscripcion) => inscripcion.tallerId === taller.id
  );

  return taller.plazas - apuntados.length;
}

// Compruebo con some() si existe ya alguna inscripción en ese taller con el mismo correo (ignorando mayúsculas)
export function estaInscrito(tallerId, email, inscripciones) {
  const correo = String(email ?? "").trim().toLowerCase();

  return inscripciones.some((inscripcion) => {
    return (
      inscripcion.tallerId === tallerId &&
      inscripcion.email.toLowerCase() === correo
    );
  });
}

// Limpio espacios sobrantes y normalizo el correo a minúsculas antes de validar o guardar los datos del formulario
export function normalizarInscripcion(body) {
  const entrada = body ?? {};

  return {
    nombre: String(entrada.nombre ?? "").trim(),
    email: String(entrada.email ?? "").trim().toLowerCase()
  };
}

// Valido longitud y formato de nombre y email, devolviendo un objeto con los errores asociados a cada campo
export function validarInscripcion(datos) {
  const errores = {};

  const nombre = String(datos?.nombre ?? "").trim();
  const email = String(datos?.email ?? "").trim();

  // Compruebo que el nombre no esté vacío y cumpla los límites de longitud
  if (nombre === "") {
    errores.nombre = "Tienes que poner el nombre";
  } else if (nombre.length < 2) {
    errores.nombre = "El nombre debe tener al menos 2 caracteres";
  } else if (nombre.length > 40) {
    errores.nombre = "El nombre es demasiado largo (máximo 40)";
  }

  // Compruebo que el correo no esté vacío, no exceda el máximo y cumpla la estructura básica usuario@dominio.ext
  const formatoEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (email === "") {
    errores.email = "Tienes que poner el email";
  } else if (email.length > 100) {
    errores.email = "El email es demasiado largo (máximo 100)";
  } else if (!formatoEmail.test(email)) {
    errores.email = "El email no es correcto";
  }

  return errores;
}

// Calculo el siguiente identificador disponible buscando el máximo actual para evitar colisiones si se eliminan elementos
export function siguienteId(lista) {
  if (lista.length === 0) {
    return 1;
  }

  return Math.max(...lista.map((elemento) => elemento.id)) + 1;
}