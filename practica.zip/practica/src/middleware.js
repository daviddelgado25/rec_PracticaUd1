// Formateo un objeto Date al patrón dd/mm/aaaa hh:mm:ss añadiendo ceros a la izquierda cuando hace falta
function formatearFecha(fecha) {
  const dos = (n) => String(n).padStart(2, "0");

  return (
    dos(fecha.getDate()) + "/" +
    dos(fecha.getMonth() + 1) + "/" +
    fecha.getFullYear() + " " +
    dos(fecha.getHours()) + ":" +
    dos(fecha.getMinutes()) + ":" +
    dos(fecha.getSeconds())
  );
}

// Imprimo por consola la fecha, el método HTTP y la URL de cada petición y cedo el paso con next()
export function registrarPeticion(req, res, next) {
  console.log("[" + formatearFecha(new Date()) + "] " + req.method + " " + req.originalUrl);
  next();
}